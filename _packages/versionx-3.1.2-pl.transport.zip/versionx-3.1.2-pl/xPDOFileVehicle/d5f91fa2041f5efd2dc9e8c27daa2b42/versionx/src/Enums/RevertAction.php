<?php

namespace modmore\VersionX\Enums;

class RevertAction {
    public const ALL = 'all';
    public const DELTA = 'delta';
    public const SINGLE = 'single';
}